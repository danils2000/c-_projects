#ifndef __SQUARE__H__
#define __SQUARE__H__

#include "point.cpp"

class Square : public Point {
public:
	Square(double cpx = 0.0, double cpy = 0.0, double w = 0.0, double h = 0.0);
	Square(const Point& cp, double w, double h); //constructor 2
	Square(const Square& c); //copy constructor
	virtual void input(const char* prompt) override;
	double getWidth() const;
	double getHeigh() const;
	void output() const override;
	double area() const;
private:
	double  width;
	double heigh;
};

#endif  //!__SQUARE__H__