#include"circle.h"

Circle::Circle(double cpx, double cpy, double r0) : Point(cpx, cpy), radius(r0) {

}

Circle::Circle(const Point& cp, double r0) : Point(cp), radius(r0) { 

}

Circle::Circle(const Circle& c) : Point(c), radius(c.radius) { 

}

void Circle::input(const char* prompt) {
	cout << prompt << endl;
	Point::input("");
	cout << "Enter radius :";
	cin >> radius;
}

void Circle::output() const {
	cout << " Circle's area : " << area();
	Point::output();
}

double Circle::getRadius() const {
	return radius;
}

double Circle::area(void) const {
	double area;
	area = M_PI * radius * radius;
	return area;
}

ostream& operator<<(ostream& out, const Square& square) {
	out << " Square area  is : " << square.area() << (Point)square;
	return out;
}
