#ifndef __POINT__H__
#define __POINT__H__

#include <iostream> 
#define NUMBER_PI 3.14
using namespace std;

class Point {
public:
	//constructor
    Point(double xcoord = 0.0, double ycoord = 0.0);
    // destructor
    virtual ~Point() = default;
	virtual void input(const char* prompt);
	virtual void output() const;
	virtual double area() const;
	double getx() const;
	double gety()const;
	void move(double deltax, double deltay);
private:
	double x;
	double y;
};

#endif  //!__POINT__H__