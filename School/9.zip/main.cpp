#include"circle.cpp"
#include"point.cpp"
#include"square.cpp"


int main() {
	// A
	vector<shared_ptr<Point>> a;
	Point point(1.0, 1.0);
	a.push_back(make_shared<Point>(point));
	point.move(2.0, 2.0);
	a.push_back(make_shared<Circle>(point, 3.0));
	point.move(5.0, 5.0);
	a.push_back(make_shared<Square>(point, 6.0, 6.0));
	for (auto p : a) {
		p->output();
	}
	cout << " Sorted:" << endl;
	sort(a.begin(), a.end(), [](const auto& p0, const auto& p1) {
		return p0->area() < p1->area();
		});

	for (auto point : a) {
		point->output();
	}

	//B
	Point point;
	Circle circle;
	Square square;
	vector<shared_ptr<Point>> b;

	point.input("\nPoint:\n");
	circle.input(" Circle: ");
	square.input(" Square: ");

	b.push_back(make_shared<Point>(point));
	point.move(square.getx(), circle.gety()); 
	b.push_back(make_shared<Circle>(point, circle.getRadius()));
	point.move(square.getx(), square.gety());
	b.push_back(make_shared<Square>(point, square.getWidth(), square.getHeigh()));
	for (auto p : b) {
		p->output();
	}
	cout << " Sorted:" << endl;
	sort(b.begin(), b.end(), [](const auto& p0, const auto& p1) {
		return p0->area() < p1->area();
		});
	for (auto p : b) {
		p->output();
	}

	// E.T 
	int num = 0;
	Point point;
	point.input("\n Point:\n");

	vector<shared_ptr<Point>> c;
	c.push_back(make_shared<Point>(point));
	for (size_t i = 0; i < 4; i++) {
		srand(time(NULL));
		num = rand() % 10 + 1;
		if (num <= 5) {

			Circle c1;
			c1.input(" Circle:");
			point.move(c1.getx(), c1.gety());
			c.push_back(make_shared<Circle>(point, c1.getRadius()));

		}
		else
		{
			Square s1;
			s1.input(" Square:"); 
			point.move(s1.getx(), s1.gety());
			c.push_back(make_shared<Square>(point, s1.getWidth(), s1.getHeigh()));
		}
	}

	for (auto p : c) {
		p->output();
	}
	cout << " Sorted:" << endl;
	sort(c.begin(), c.end(), [](const auto& p0, const auto& p1) {
		return p0->area() < p1->area();
		});
	for (auto p : c) {
		p->output();
	}
	return 0;
}

