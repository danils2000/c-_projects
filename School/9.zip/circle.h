#ifndef __CIRCLE__H__
#define __CIRCLE__H__

#include "point.cpp"

class Circle : public Point {
public:
	Circle(double cpx = 0.0, double cpy = 0.0, double r = 1.0);
	Circle(const Point& cp, double r);
	Circle(const Circle& c);
	virtual void input(const char* prompt) override;
	void output() const override;
	double getRadius() const;
	double area() const;
private:
	double radius;
};

#endif  //!__CIRCLE__H__