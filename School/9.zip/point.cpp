#include <vector>
#include <string>
#include <math.h>
#include <time.h>   
#include "point.h"   

Point::Point(double xcoord, double ycoord) {
	x = xcoord;
	y = ycoord;
}

void Point::input(const char* prompt) {
	cout << prompt;
	cout << " Enter x:";
	cin >> x;
	cout << " Enter y:";
	cin >> y;
}

void Point::output() const {
	cout << " Coordinates: (" << getx() << "," << gety() << ")" << endl;
}

double Point::area() const {
	return 0.0;
}

double Point::getx(void)const {
	return x;
}
double Point::gety(void) const {
	return y;
}

void Point::move(double deltax, double deltay) {
	x += deltax;
	y += deltay;
}

ostream& operator<<(ostream& out, const Point& point) {
	out << " X is : " << point.getx() << ", and Y is " << point.gety();
	return out;
}