#include"square.h"


Square::Square(double cpx, double cpy, double w0, double h0) : Point(cpx, cpy), width(w0), heigh(h0) { 

}

Square::Square(const Point& cp, double w0, double h0) : Point(cp), width(w0), heigh(h0) { 

}

Square::Square(const Square& s) : Point(s), width(s.width), heigh(s.heigh) { 

}

void Square::input(const char* prompt) {
	cout << prompt << endl;
	Point::input(""); 
	cout << "Enter width :";
	cin >> width;
	cout << "Enter heigh :";
	cin >> heigh;
}

double Square::getWidth() const {
	return width;
}

double Square::getHeigh() const {
	return heigh;
}

void Square::output() const {
	cout << " Square's area : " << area();
	Point::output();
}

double Square::area(void) const {
	double area;
	area = width * heigh;
	return area;
}

ostream& operator<<(ostream& out, const Square& square) {
	out << " Square area  is : " << square.area() << (Point)square;
	return out;
}
