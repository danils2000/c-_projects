#pragma once
#ifndef LAB7_H_INCLUDED
#define LAB7_H_INCLUDED
#include <iostream>
#include <string>
#include <algorithm> 
#include <vector>
#include <iterator>  
#include <set>
using namespace std;

//Function object
class RandGen_2 {
public:
    void func();
    int randGen_1(int numbers);
	RandGen_2(int range = 0, int num = 0);
	RandGen_2() : numbers() {
         srand(time(NULL)); 
    }
	int operator()();
private:
	vector<int> numbers;
	int range;
	int num;
};

#endif
