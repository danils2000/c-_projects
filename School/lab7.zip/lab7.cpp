#include "lab7.h"

using namespace std;

int randGen_1(int numbers) {
	return rand() % numbers + 1;
}

void func() {
char choise = 'n';
	do {
	srand(time(NULL));
	ostream_iterator<int> out_it(cout, " ");
	vector<int> s;
	vector<int> s2;

//LOTTO
	//7 numbers
	vector<int> numbers_lotto(7);
	//from 1 to 40, 7 num
	RandGen_2 randGen_1(40, 7);
	//generate
	generate(numbers_lotto.begin(), numbers_lotto.end(), randGen_1);
	cout << "Lotto: ";
	//print
	copy(numbers_lotto.begin(), numbers_lotto.end(), out_it);

	cout << endl;

//VIKING
	vector<int> numbers_viking(7);
	RandGen_2 randGen_2(48, 6);
	generate(numbers_viking.begin(), numbers_viking.end(), randGen_2);
	cout << "Viking lotto: ";
	copy(numbers_viking.begin(), numbers_viking.end(), out_it);


	//matching numbers for lotoo and viking
	cout << "\nMatching numbers: " << endl;
	sort(numbers_lotto.begin(), numbers_lotto.end());
	sort(numbers_viking.begin(), numbers_viking.end());
	set_intersection(numbers_lotto.begin(), numbers_lotto.end(), numbers_viking.begin(), numbers_viking.end(), back_inserter(s));
	int count = 0;

	for_each(s.begin(), s.end(), [&count](int x) {
		count = count + 1;
		cout << "#" << count << ":" << x << endl;
	});


//EUROJACKPOT
	vector<int> numbers_eurojackpot(5);
	RandGen_2 randGen_3(50, 5);
	generate(numbers_eurojackpot.begin(), numbers_eurojackpot.end(), randGen_3);
	cout << "Eurojackport:  ";
	copy(numbers_eurojackpot.begin(), numbers_eurojackpot.end(), out_it);

	cout << "\nMatching numbers in three sets: " << endl;
	count = 0;
	sort(s.begin(), s.end());
	sort(numbers_eurojackpot.begin(), numbers_eurojackpot.end());
	set_intersection(s.begin(), s.end(),
		numbers_eurojackpot.begin(), numbers_eurojackpot.end(),
		back_inserter(s2));
	for_each(s2.begin(), s2.end(), [&count](int x) {
		count = count + 1;
		cout << "#" << count << ":" << x << endl;
		});


//again
	do {
		cout << "\nContinue [Y/N]? ";
		cin >> choise;
		if (toupper(choise) != 'Y' && toupper(choise) != 'N') {
			cout << "\nInvalid answer. Try gain!" << endl;
		}
	
	}while (toupper(choise) != 'Y' && toupper(choise) != 'N');
	
	}while (toupper(choise) == 'Y');
}

RandGen_2::RandGen_2(int r, int n) { // Initializatio
	range = r;
	num = n;
}

int RandGen_2::operator()() {
	int number;
	do {
		number = rand() % range + 1;
		num--;
	} while (find(numbers.begin(), numbers.end(), number) != numbers.end());

	numbers.push_back(number);
	return number;
}


int main() {
	func();
}
